// pages/article/article.js
var WxParse = require('../../wxParse/wxParse.js');
var dgyApi = require('../../dgyApi/dgyApi') // 导入dgyApi
Page({

  /**
   * 页面的初始数据
   */
  data: {
    modelid: "",
    id: "",
    title: "",
    say: "",
    score: "",
    articleThumb: "",
    favoriteType: false,
    starText: "收藏"
  },
  /** 收藏 */
  favoriteMode: function (e) {
    var that = this;
    var _id = e.currentTarget.dataset.id;
    var _modelid = e.currentTarget.dataset.modelid;
    var _thumb = e.currentTarget.dataset.thumb;
    var _title = e.currentTarget.dataset.title;
    var _say = e.currentTarget.dataset.say;
    var _score = e.currentTarget.dataset.score;
    var _baseUrl = 'https://demo.duoguyu.com';
    //取出本地存储数据
    wx.getStorage({
      key: "demoDuoguyu",
      success: function (res) {
        var demoDuoguyu = res.data;
        var _starData = { "id": _id, "modelid": _modelid, "thumb": _baseUrl+_thumb, "title": _title, "say": _say, "score": _score };
        var _userStar = res.data.userStar;
        // 是否首次收藏该内容
        if (_userStar == null || _userStar == "") {
          _userStar.push(_starData);
          that.setData({
            favoriteType: true,
            starText: "已收藏"
          });
          // 完成后，存储
          wx.setStorageSync("demoDuoguyu", demoDuoguyu);
        } else {
          var result = false;
          //查找已收藏列表中是否有该内容，有的话就移除收藏  
          for (var i in _userStar) {
            if (_userStar[i].id == _starData.id) {
              _userStar.splice(i, 1);
              that.setData({
                favoriteType: false,
                starText: "收藏"
              });
              // 完成后，存储
              wx.setStorageSync("demoDuoguyu", demoDuoguyu);
              result = true;
            }
          }
          if (!result) {
            //如果没有，就收藏进去
            _userStar.push(_starData);
            that.setData({
              favoriteType: true,
              starText: "已收藏"
            });
            // 完成后，存储
            wx.setStorageSync("demoDuoguyu", demoDuoguyu);
          }
        }
      },
      fail: function (res) {
        wx.showToast({
          title: '请先登录',
          icon: 'loading',
          duration: 2000
        });

      }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.showLoading({
      title: '玩命加载中',
      mask: true
    });
    if (options.id) {
        var _modelid = options.modelid;
        var _id = options.id;
        var _baseUrl = 'https://demo.duoguyu.com';
        wx.request({
          url: dgyApi.contentUrl,
          data: {
            "modelid": _modelid,
            "id": _id
          },
          method: 'POST', 
          header: {'Content-Type': 'application/x-www-form-urlencoded'},
          success: function (res) {
            if (res.data.status == 1) {
              var _articleData = res.data.data;
              that.setData({
                articleData: _articleData,
                modelid: _modelid,
                id: _id,
                title: _articleData.title,
                say: _articleData.say,
                score: _articleData.score,
                articleThumb: _baseUrl + _articleData.thumb,
              });

              wx.setNavigationBarTitle({
                title: _articleData.title
              });

              var article = _articleData.content;
              WxParse.wxParse('article', 'html', article, that, 5);
              wx.hideLoading();

              // 判断是否已存在本地收藏夹里
              wx.getStorage({
                key: "demoDuoguyu",
                success: function (res) {
                  var demoDuoguyu = res.data;
                  var _userStar = res.data.userStar;
                  var _userView = res.data.userView;
                  for (var i in _userStar) {
                    if (_userStar[i].id == options.id) {
                      that.setData({
                        favoriteType: true,
                        starText: "已收藏"
                      });
                    }
                  }

                },
                fail: function (res) {
                }
              });


            }
          },
          fail: function () {
            // fail  
          },
          complete: function () {
            // complete  
          }
        })

     }
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function(){

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})