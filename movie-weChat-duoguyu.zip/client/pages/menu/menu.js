var dgyApi = require('../../dgyApi/dgyApi') // 导入dgyApi
Page({

  /**
   * 页面的初始数据
   */
  data: {
    page: 1,
    modelid: 1,
    catid: 1,
    articles: [],
    navList:[],
    currentTab: '0',
    articleId: '0',
    loadStatus: true
  }, 
  // 上拉加载内容
  loadPage: function (pageNo, catid, modelid, switchStatus) {
    var that = this;
    wx.request({
      url: dgyApi.baseUrl,
      data: {
        "modelid": modelid,
        "catid": catid,
        "page": pageNo
      },
      method: 'POST',
      header: {'Content-Type': 'application/x-www-form-urlencoded' },
      success: function (res) {
        if (res.data.status == 1 && res.data.data.length != 0) {
          var _data = res.data.data;
          if (switchStatus != '1') {
            that.setData({
              page: pageNo,
              modelid: modelid,
              catid: catid,
              articles: that.data.articles.concat(_data),
              articleId: catid,
              loadStatus: true
            });
          } else {
            that.setData({
              page: pageNo,
              modelid : modelid,
              catid : catid,
              articles: _data,
              articleId: catid,
              loadStatus: true
            });
          }
        } else {
          that.setData({
            loadStatus: false,
            articleId: catid
          });
        }
      },
      fail: function () {
        // fail  
      },
      complete: function () {
        // complete  
      }

    })
  },

  // 切换菜单
  switchMovMenu: function (e) {
    var catid = e.currentTarget.dataset.catid;
    var modelid = e.currentTarget.dataset.modelid;
    this.loadPage(1, catid, modelid, 1);
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 0
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loadPage(1,1,1);
    var that = this;
    // nav
    wx.request({
      url: dgyApi.navUrl,
      data: {},
      method: 'POST',
      header: { 'Content-Type': 'application/x-www-form-urlencoded' },
      success: function (res) {
        if (res.data.status == 1) {
          var _navList = res.data.data;
          that.setData({
            navList: _navList
          });

        }
      },
      fail: function () {
        // fail  
      },
      complete: function () {
        // complete  
      }
    });

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var newPageNo = this.data.page + 1;
    var catid = this.data.catid; //取得catid的值
    var modelid = this.data.modelid; //取得modelid的值
    this.loadPage(newPageNo, catid, modelid);
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})