var dgyApi = require('../../dgyApi/dgyApi') // 导入dgyApi
Page({

  /**
   * 页面的初始数据
   */
  data: {
    page: 1,
    articles: [],
    loadStatus: '多骨鱼.',
  },
  loadPage: function (pageNo, options, _type) {
    var that = this;
    if (_type == "1") { //tag查询
      wx.request({
        url: dgyApi.tagSearchUrl,
        data: {
          "modelid": options.modelid,
          "id": options.catid,
          "page": pageNo
        },
        method: 'POST',
        header: { 'Content-Type': 'application/x-www-form-urlencoded' },
        success: function (res) {
          if (res.data.status == 1 && res.data.data.length != 0) {
            var _data = res.data.data;
            that.setData({
              page: pageNo,
              articles: that.data.articles.concat(_data)
            });

          } else {
            that.setData({
              loadStatus: '没有更多数据咯.'
            });
          }
        },
        fail: function () {
          // fail  
        },
        complete: function () {
          // complete  
        }

      })
    } else { //通用查询
      wx.request({
        url: dgyApi.baseUrl,
        data: {
          "modelid": options.modelid,
          "q": options.q,
          "page": pageNo
        },
        method: 'POST',
        header: { 'Content-Type': 'application/x-www-form-urlencoded' },
        success: function (res) {
          if (res.data.status == 1 && res.data.data.length != 0) {
            var _data = res.data.data;
            that.setData({
              page: pageNo,
              articles: that.data.articles.concat(_data)
            });

          } else {
            that.setData({
              loadStatus: '没有更多数据咯.'
            });
          }
        },
        fail: function () {
          // fail  
        },
        complete: function () {
          // complete  
        }

      })
    }

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loadPage(1, options, options.type);
    wx.setNavigationBarTitle({
      title: options.catname //catname
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function (options) {
    var newPageNo = this.data.page + 1;
    this.loadPage(newPageNo, options, options.type);

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})