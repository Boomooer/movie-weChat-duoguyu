Page({

  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl: 'https://demo.duoguyu.com/dist/default-user-avatar.png',
    nickName: '匿名大神',
    favoriteListData: [],
    userStarNum:'0',
    pageStatus: false,
    getStorageType: false,
    loginToastType: false,
    baseUrl : 'https://demo.duoguyu.com',
    aboutLofterStatus: false,
    aboutMeStatus: false
  },
  openLofterToast: function () {
    var that = this;
    that.setData({
      aboutLofterStatus: true
    });
  },
  closeLofterToast: function () {
    var that = this;
    that.setData({
      aboutLofterStatus: false
    });
  },
  openMeToast: function () {
    var that = this;
    that.setData({
      aboutMeStatus: true
    });
  },
  closeMeToast: function () {
    var that = this;
    that.setData({
      aboutMeStatus: false
    });
  },
  totalStarNum:function(){
    var that = this;
    //取出本地存储数据
    wx.getStorage({
      key: "demoDuoguyu",
      success: function (res) {
        var userStar = res.data.userStar;
        var userStarLength = userStar.length;
        that.setData({
          userStarNum: userStarLength,
          getStorageType: true,
          loginToastType: false
        });
      },
      fail: function (res) {
        that.setData({
          getStorageType: false,
          loginToastType: true,
        });
      }
    });
  },
  onGotUserInfo: function (e) {
    var that = this;
    var _userInfo = e.detail.userInfo;
    var _avatarUrl = _userInfo.avatarUrl;
    var _nickName = _userInfo.nickName;

    /**
     * 
     * 这里可以使用 wx.login 方法，获取用户的openid，使用openid作为唯一id存储到本地或注册到后台。
     * 我下面仅仅提供一个简单的存储本地数据demo
     * 
     */


    //取到openid后.存储到本地
    var _newUserInfo = { "nickName": _nickName }; // 用户信息
    var _userStarInfo = []; // 用户收藏
    var demoDuoguyu = { "userInfo": _newUserInfo, "userStar": _userStarInfo };
    wx.setStorageSync("demoDuoguyu", demoDuoguyu);
    that.setData({
      getStorageType: true,
      loginToastType: false
    });
    

  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.totalStarNum();
    

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (this.data.pageStatus) {
      this.totalStarNum();
      this.closeMeToast();
      this.closeLofterToast();
    }

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

    this.setData({
      pageStatus: true
    });

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})