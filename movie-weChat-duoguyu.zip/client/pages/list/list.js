var dgyApi = require('../../dgyApi/dgyApi') // 导入dgyApi
Page({

  /**
   * 页面的初始数据
   */
  data: {
    page: 1,
    articles: [],
    loadStatus: '多骨鱼.',
    loadStatus: true,
    _type: '1',
    id: '',
    modelid: '1',
    q:'',
  },
  loadPage: function (pageNo, modelid, id_Q, _type) {
    var that = this;
    if (_type == "1"){
      wx.request({
        url: dgyApi.tagSearchUrl,
        data: {
          "modelid": modelid,
          "id": id_Q,
          "page": pageNo
        },
        method: 'POST',
        header: { 'Content-Type': 'application/x-www-form-urlencoded' },
        success: function (res) {
          if (res.data.status == 1 && res.data.data.length != 0) {
            var _data = res.data.data;
            that.setData({
              page: pageNo,
              id: id_Q,
              modelid: modelid,
              _type: _type,
              articles: that.data.articles.concat(_data),
              loadStatus: true
            });

          } else {
            that.setData({
              loadStatus: false,
              id: id_Q,
              modelid: modelid,
            });
          }
        },
        fail: function () {
          // fail  
        },
        complete: function () {
          // complete  
        }

      })
    }else{ //通用查询
      wx.request({
        url: dgyApi.baseUrl,
        data: {
          "modelid": modelid,
          "q": id_Q,
          "page": pageNo
        },
        method: 'POST',
        header: { 'Content-Type': 'application/x-www-form-urlencoded' },
        success: function (res) {
          if (res.data.status == 1 && res.data.data.length != 0) {
            var _data = res.data.data;
            that.setData({
              page: pageNo,
              q: id_Q,
              modelid: modelid,
              articles: that.data.articles.concat(_data),
              loadStatus: true
            });

          } else {
            that.setData({
              loadStatus: false,
              q: id_Q,
              modelid: modelid,
            });
          }
        },
        fail: function () {
          // fail  
        },
        complete: function () {
          // complete  
        }

      })
    }
    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.type == '1'){
      this.loadPage(1, options.modelid, options.id, options.type);
    }else{
      this.loadPage(1, options.modelid, options.q);
    }

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function (options) {
    var newPageNo = this.data.page + 1;
    var id = this.data.id;
    var modelid = this.data.modelid;
    var _thisQ = this.data.q;
    var _type = this.data._type;
    if (_type == '1') {
      this.loadPage(newPageNo, modelid, id, _type);
    } else {
      this.loadPage(newPageNo, modelid, _thisQ);
    }

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})