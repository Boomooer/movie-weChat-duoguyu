var dgyApi = require('../../dgyApi/dgyApi') // 导入dgyApi
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wxSearchData: '',
    articles: [],
    loadStatus: '',
    searchStatus: false,
    openIdTest:''
  },
  /**
   * 搜索
   */
  wxSearchInput: function (value) {
    var that = this;
    if (value.length > 0) {
      wx.request({
        url: dgyApi.baseUrl,
        data: {
          "modelid": "1",
          "q": value
        },
        method: 'POST',
        header: { 'Content-Type': 'application/x-www-form-urlencoded' },
        success: function (res) {
          if (res.data.status == 1 && res.data.data.length != 0) {
            that.setData({
              searchStatus: true,
              articles: res.data.data
            });
          } else {
            that.setData({
              loadStatus: '没有更多数据咯.',
              searchStatus: true
            });
          }
        },
        fail: function () {
          // fail  
        },
        complete: function () {
          // complete  
        }

      })
    }else{
      that.setData({
        loadStatus: '',
        searchStatus: false
      });
    }
  },

  /**
   * 监听软键盘确认键
   */
  wxSearchConfirm: function (e) {
    this.wxSearchInput(e.detail.value);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 热门电影
    wx.request({
      url: dgyApi.baseUrl,
      data: {
        "modelid": "1",
        "catid": "1",
        "page": "1",
        "limit": "5"
      },
      method: 'POST',
      header: { 'Content-Type': 'application/x-www-form-urlencoded' },
      success: function (res) {
        if (res.data.status == 1 && res.data.data.length != 0) {
          var _data = res.data.data;
          that.setData({
            articles: _data
          });
        }
      },
      fail: function () {
        // fail  
      },
      complete: function () {
        // complete  
      }

    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})