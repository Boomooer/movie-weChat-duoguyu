var dgyApi = require('../../dgyApi/dgyApi') // 导入dgyApi
Page({

  /**
   * 页面的初始数据
   */
  data: {
    page: 1,
    articles: [],
    loadStatus: '多骨鱼.',
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // banner
    wx.request({
      url: dgyApi.bannerUrl,
      data: {},
      method: 'POST',
      header: { 'Content-Type': 'application/x-www-form-urlencoded' },
      success: function (res) {
        if (res.data.status == 1) {
          that.setData({
            bannerList: res.data.data
          });
        }
      },
      fail: function () {
        // fail  
      },
      complete: function () {
        // complete  
      }
    });

    // tag
    wx.request({
      url: dgyApi.tagUrl,
      data: {},
      method: 'POST',
      header: { 'Content-Type': 'application/x-www-form-urlencoded' },
      success: function (res) {
        if (res.data.status == 1) {
          var arr = res.data.data
          var _newTagList = [];
          for (var i = 0; i < arr.length; i++) {
            var imgNum = i + 1;
            var imgName = 'https://demo.duoguyu.com/dist/tag_'+ imgNum +'.jpg';
            var obj = { id: i + 1, tag: arr[i].tag, img: imgName };
            _newTagList.push(obj);
          };
          that.setData({
            tagList: _newTagList
          });
        }
      },
      fail: function () {
        // fail  
      },
      complete: function () {
        // complete  
      }
    });

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }

})