/**
 * 多骨鱼 Api配置文件
 */

// 基础接口
var baseUrl = 'https://demo.duoguyu.com/index/api';
var dgyApi = {
  // 列表
  baseUrl,
  // 导航
  navUrl: `${baseUrl}/nav`,
  // 详情
  contentUrl: `${baseUrl}/content`,
  // banner
  bannerUrl: `${baseUrl}/banner`,
  // 标签
  tagUrl: `${baseUrl}/tag`,
  // 标签搜索
  tagSearchUrl: `${baseUrl}/tag_search`
};
module.exports = dgyApi;
